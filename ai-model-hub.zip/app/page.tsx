"use client";

import { useMemo, useState } from "react";
import ModelCard from "@/components/ModelCard";
import SearchBar from "@/components/SearchBar";
import FilterBar from "@/components/FilterBar";
import { models } from "@/data/models";

export default function HomePage() {
  const [query, setQuery] = useState("");
  const [type, setType] = useState("All types");
  const [source, setSource] = useState("all");
  const [price, setPrice] = useState("all");

  const filteredModels = useMemo(() => models.filter((model) => {
    const search = query.toLowerCase().trim();
    const matchesSearch = !search || [model.name, model.provider, model.description, ...model.tags].some((item) => item.toLowerCase().includes(search));
    const matchesType = type === "All types" || model.type === type;
    const matchesSource = source === "all" || (source === "open" ? model.isOpenSource : !model.isOpenSource);
    const matchesPrice = price === "all" || (price === "free" ? model.isFree : !model.isFree);
    return matchesSearch && matchesType && matchesSource && matchesPrice;
  }), [query, type, source, price]);

  return <main>
    <section className="relative overflow-hidden border-b border-line/70">
      <div className="pointer-events-none absolute left-1/2 top-[-250px] h-[500px] w-[850px] -translate-x-1/2 rounded-full bg-blue-500/10 blur-[110px]" />
      <div className="relative mx-auto max-w-7xl px-4 pb-14 pt-16 sm:px-6 sm:pb-20 sm:pt-24 lg:px-8">
        <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-blue-400/20 bg-blue-400/5 px-3 py-1.5 text-xs font-medium text-blue-300"><span className="h-1.5 w-1.5 rounded-full bg-blue-400" /> Your AI model discovery workspace</div>
        <h1 className="max-w-4xl text-4xl font-semibold leading-[1.08] tracking-[-.045em] text-white sm:text-6xl">Find the right AI model<br className="hidden sm:block" /> for <span className="bg-gradient-to-r from-blue-300 to-indigo-400 bg-clip-text text-transparent">what you want to build.</span></h1>
        <p className="mt-5 max-w-2xl text-base leading-7 text-slate-400 sm:text-lg">Search, compare, and evaluate language, image, and audio models. Understand capabilities, access options, and deployment fit — all in one place.</p>
        <div className="mt-9 grid max-w-3xl grid-cols-3 gap-3 sm:gap-5">
          {[["10", "Curated models"],["4", "Model categories"],["1", "Simple workspace"]].map(([number, label]) => <div key={label} className="rounded-2xl border border-line/80 bg-panel/60 p-3 sm:p-4"><p className="text-xl font-semibold text-white sm:text-2xl">{number}</p><p className="mt-1 text-[11px] text-slate-500 sm:text-xs">{label}</p></div>)}
        </div>
      </div>
    </section>
    <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-14 lg:px-8">
      <div className="mb-6 flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between"><div><p className="text-xs font-semibold uppercase tracking-[.2em] text-blue-300">Model directory</p><h2 className="mt-2 text-2xl font-semibold tracking-tight text-white">Explore AI models</h2></div><p className="text-sm text-slate-500">Showing <span className="font-semibold text-slate-200">{filteredModels.length}</span> of {models.length} models</p></div>
      <div className="mb-4"><SearchBar value={query} onChange={setQuery} /></div>
      <FilterBar type={type} setType={setType} source={source} setSource={setSource} price={price} setPrice={setPrice} />
      {filteredModels.length ? <div className="mt-7 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{filteredModels.map((model) => <ModelCard key={model.slug} model={model} />)}</div> : <div className="mt-8 rounded-2xl border border-dashed border-line p-12 text-center"><p className="font-medium text-white">No models found</p><p className="mt-2 text-sm text-slate-500">Try a different search or clear one of your filters.</p><button onClick={() => { setQuery(""); setType("All types"); setSource("all"); setPrice("all"); }} className="mt-4 rounded-lg bg-blue-500 px-4 py-2 text-sm font-semibold text-white">Clear filters</button></div>}
      <div className="mt-12 rounded-2xl border border-line bg-gradient-to-br from-panel to-blue-950/20 p-6 sm:flex sm:items-center sm:justify-between sm:p-8"><div><p className="text-xs font-semibold uppercase tracking-widest text-blue-300">Build with confidence</p><h3 className="mt-2 text-xl font-semibold text-white">Shortlist models before you commit.</h3><p className="mt-2 max-w-xl text-sm leading-6 text-slate-400">Compare deployment options, licensing, context windows, and best-fit use cases in one view.</p></div><a href="/compare" className="mt-5 inline-flex rounded-xl border border-blue-400/30 bg-blue-500/10 px-4 py-3 text-sm font-semibold text-blue-200 hover:bg-blue-500/20 sm:mt-0">Compare models ↗</a></div>
    </section>
  </main>;
}
