import Link from "next/link";

export default function NotFound() {
  return <main className="flex min-h-[65vh] flex-col items-center justify-center px-4 text-center">
    <p className="text-sm font-semibold uppercase tracking-[.25em] text-blue-300">Error 404</p>
    <h1 className="mt-4 text-6xl font-semibold tracking-tight text-white">Page not found</h1>
    <p className="mt-4 max-w-md text-sm leading-6 text-slate-400">The page or model you are looking for does not exist, or may have moved.</p>
    <Link href="/" className="mt-7 rounded-xl bg-blue-500 px-5 py-3 text-sm font-semibold text-white hover:bg-blue-400">Go back home</Link>
  </main>;
}
