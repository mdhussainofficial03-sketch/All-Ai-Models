import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getModel, models } from "@/data/models";
import { formatContext } from "@/lib/utils";
import PriceBadge from "@/components/PriceBadge";

type Props = { params: { slug: string } };

export function generateStaticParams() {
  return models.map((model) => ({ slug: model.slug }));
}

export function generateMetadata({ params }: Props): Metadata {
  const model = getModel(params.slug);
  return { title: model ? model.name : "Model not found", description: model?.description };
}

export default function ModelDetailPage({ params }: Props) {
  const model = getModel(params.slug);
  if (!model) notFound();

  const details = [
    ["Provider", model.provider], ["Type", model.type], ["Context length", model.contextLength ? `${formatContext(model.contextLength)} tokens` : "Not applicable"],
    ["License", model.license], ["Release date", model.releaseDate], ["Benchmark score", `${model.benchmarkScore}/100 (sample hub score)`],
    ["Access", model.isFree ? "Free access / open weights" : "Paid or freemium access"], ["Open source", model.isOpenSource ? "Yes — verify license terms" : "No — commercial/proprietary"]
  ];

  return <main className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-14 lg:px-8">
    <Link href="/" className="text-sm text-slate-500 transition hover:text-white">← Back to model directory</Link>
    <section className="mt-7 rounded-3xl border border-line bg-panel p-6 sm:p-10">
      <div className="flex flex-col gap-6 sm:flex-row sm:items-start sm:justify-between">
        <div className="max-w-3xl"><div className="flex flex-wrap items-center gap-2"><span className="rounded-full border border-blue-400/20 bg-blue-400/10 px-3 py-1 text-xs text-blue-300">{model.category}</span><PriceBadge label={model.pricingLabel} /></div><p className="mt-5 text-xs font-semibold uppercase tracking-[.2em] text-slate-500">{model.provider}</p><h1 className="mt-2 text-4xl font-semibold tracking-tight text-white sm:text-5xl">{model.name}</h1><p className="mt-5 max-w-2xl text-base leading-7 text-slate-400">{model.description}</p><div className="mt-5 flex flex-wrap gap-2">{model.tags.map((tag) => <span key={tag} className="rounded-lg border border-line px-3 py-1.5 text-xs text-slate-300">#{tag}</span>)}</div></div>
        <div className="min-w-[160px] rounded-2xl border border-line bg-ink/60 p-5"><p className="text-xs text-slate-500">Sample hub score</p><p className="mt-2 text-4xl font-semibold text-white">{model.benchmarkScore}<span className="text-base text-slate-500">/100</span></p><p className="mt-2 text-xs text-slate-500">Illustrative, not a live benchmark</p></div>
      </div>
    </section>
    <div className="mt-6 grid gap-6 lg:grid-cols-[1.2fr_.8fr]">
      <section className="rounded-2xl border border-line bg-panel p-6"><h2 className="text-lg font-semibold text-white">Model specifications</h2><dl className="mt-5 grid gap-0 sm:grid-cols-2">{details.map(([label, value]) => <div key={label} className="border-t border-line py-4"><dt className="text-xs text-slate-500">{label}</dt><dd className="mt-1.5 text-sm font-medium text-slate-200">{value}</dd></div>)}</dl></section>
      <div className="space-y-6">
        <section className="rounded-2xl border border-line bg-panel p-6"><h2 className="text-lg font-semibold text-white">Best fit</h2><p className="mt-3 text-sm leading-6 text-slate-400">{model.bestFor}.</p><div className="mt-5 space-y-3 text-sm"><p className="flex items-center gap-2 text-slate-300"><span className={model.localSupport ? "text-emerald-300" : "text-slate-600"}>{model.localSupport ? "✓" : "—"}</span> Local deployment option</p><p className="flex items-center gap-2 text-slate-300"><span className={model.isOpenSource ? "text-emerald-300" : "text-slate-600"}>{model.isOpenSource ? "✓" : "—"}</span> Open weights / source available</p></div></section>
        <section className="rounded-2xl border border-line bg-panel p-6"><h2 className="text-lg font-semibold text-white">Free vs paid</h2><div className="mt-4 grid grid-cols-2 gap-3"><div className="rounded-xl border border-emerald-400/20 bg-emerald-400/5 p-3"><p className="text-xs text-emerald-300">Free route</p><p className="mt-2 text-sm font-medium text-white">{model.isFree ? "Potentially available" : "No free model license"}</p><p className="mt-1 text-xs leading-5 text-slate-500">Check hosting and usage limits.</p></div><div className="rounded-xl border border-amber-300/20 bg-amber-300/5 p-3"><p className="text-xs text-amber-200">Paid route</p><p className="mt-2 text-sm font-medium text-white">{model.isFree ? "Optional hosted APIs" : "Provider/API access"}</p><p className="mt-1 text-xs leading-5 text-slate-500">Pricing may change by provider.</p></div></div></section>
        <section className="rounded-2xl border border-line bg-panel p-6"><h2 className="text-lg font-semibold text-white">Official resources</h2><div className="mt-4 grid grid-cols-2 gap-2">{[["Official site", model.homepageUrl],["Documentation", model.docsUrl],["GitHub", model.githubUrl],["Hugging Face", model.hfUrl]].map(([label, url]) => <a key={label} href={url} target="_blank" rel="noreferrer" className="rounded-xl border border-line px-3 py-3 text-sm text-slate-300 transition hover:border-slate-500 hover:text-white">{label} ↗</a>)}</div></section>
      </div>
    </div>
    <p className="mt-6 text-xs leading-5 text-slate-500">Data note: this starter uses static sample metadata. Names, availability, licensing, release details, and prices should be checked against official sources before commercial use.</p>
  </main>;
}
