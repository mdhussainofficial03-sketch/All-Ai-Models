import type { Metadata } from "next";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: { default: "AI Model Hub — Find your next AI model", template: "%s | AI Model Hub" },
  description: "Explore, compare, and evaluate AI models in one place.",
};

function Logo() {
  return <Link href="/" className="flex items-center gap-2.5" aria-label="AI Model Hub home">
    <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-blue-500 text-lg font-black text-white shadow-glow">✳</span>
    <span className="text-sm font-bold tracking-tight text-white sm:text-base">AI Model <span className="text-blue-400">Hub</span></span>
  </Link>;
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>
    <header className="sticky top-0 z-40 border-b border-line/80 bg-ink/85 backdrop-blur-xl">
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
        <Logo />
        <div className="flex items-center gap-4 text-xs font-medium text-slate-400 sm:gap-7 sm:text-sm">
          <Link href="/" className="transition hover:text-white">Explore</Link>
          <Link href="/compare" className="transition hover:text-white">Compare</Link>
          <Link href="/pricing" className="transition hover:text-white">Pricing</Link>
          <span className="hidden rounded-full border border-emerald-400/20 bg-emerald-400/10 px-2.5 py-1 text-[11px] text-emerald-300 md:inline-flex">Directory preview</span>
        </div>
      </nav>
    </header>
    {children}
    <footer className="mt-20 border-t border-line">
      <div className="mx-auto flex max-w-7xl flex-col gap-3 px-4 py-8 text-xs text-slate-500 sm:flex-row sm:items-center sm:justify-between sm:px-6 lg:px-8">
        <p>© {new Date().getFullYear()} AI Model Hub. Independent model discovery.</p>
        <p>Sample metadata for exploration only · Always verify provider pricing and licenses.</p>
      </div>
    </footer>
  </body></html>;
}
