import Link from "next/link";
import { models } from "@/data/models";
import { formatContext } from "@/lib/utils";
import PriceBadge from "@/components/PriceBadge";

export const metadata = { title: "Compare models" };

export default function ComparePage() {
  const first = models.find((model) => model.slug === "llama-3-1-70b")!;
  const second = models.find((model) => model.slug === "gpt-4o")!;
  const rows: Array<[string, string, string]> = [
    ["Provider", first.provider, second.provider],
    ["Type", first.type, second.type],
    ["Context length", `${formatContext(first.contextLength)} tokens`, `${formatContext(second.contextLength)} tokens`],
    ["Open source / weights", first.isOpenSource ? "Yes" : "No", second.isOpenSource ? "Yes" : "No"],
    ["Local run", first.localSupport ? "Supported with suitable hardware" : "No", second.localSupport ? "Supported" : "Hosted API"],
    ["Price model", first.pricingLabel, second.pricingLabel],
    ["Best for", first.bestFor, second.bestFor]
  ];
  return <main className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-14 lg:px-8">
    <Link href="/" className="text-sm text-slate-500 hover:text-white">← Back to directory</Link>
    <div className="mt-7 max-w-3xl"><p className="text-xs font-semibold uppercase tracking-[.2em] text-blue-300">Side by side</p><h1 className="mt-2 text-4xl font-semibold tracking-tight text-white">Compare models</h1><p className="mt-4 text-slate-400">A starter comparison of an open-weight model and a commercial multimodal model.</p></div>
    <div className="mt-8 overflow-x-auto rounded-2xl border border-line bg-panel">
      <table className="w-full min-w-[650px] border-collapse text-left text-sm">
        <thead><tr className="border-b border-line"><th className="w-1/4 p-5 text-xs uppercase tracking-wider text-slate-500">Specification</th>{[first, second].map((model) => <th key={model.slug} className="p-5"><p className="text-xs text-slate-500">{model.provider}</p><p className="mt-1 text-lg font-semibold text-white">{model.name}</p><div className="mt-2"><PriceBadge label={model.pricingLabel} /></div></th>)}</tr></thead>
        <tbody>{rows.map(([label, a, b]) => <tr key={label} className="border-b border-line last:border-0"><th className="p-5 align-top text-xs font-medium text-slate-500">{label}</th><td className="p-5 align-top leading-6 text-slate-200">{a}</td><td className="p-5 align-top leading-6 text-slate-200">{b}</td></tr>)}</tbody>
      </table>
    </div>
    <p className="mt-4 text-xs leading-5 text-slate-500">Scores and sample metadata are illustrative. Compare current official documentation, license terms, and pricing before selecting a model.</p>
  </main>;
}
