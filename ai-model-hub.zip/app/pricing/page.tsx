import Link from "next/link";

const modelAccess = [
  { title: "Free", eyebrow: "Start exploring", price: "$0", description: "Basic discovery tools for learners, builders, and curious teams.", features: ["Search and browse model listings", "Core model specifications", "Limited side-by-side comparison"], featured: false },
  { title: "Pro", eyebrow: "For serious builders", price: "Planned", description: "A future paid tier for deeper evaluation and repeatable workflows.", features: ["Advanced filters and saved comparisons", "Premium comparison reports", "Model leaderboard subscriptions"], featured: true },
  { title: "Enterprise", eyebrow: "For teams", price: "Custom", description: "A future plan for organizations evaluating models at scale.", features: ["Team workspaces and evaluation notes", "Analytics and API access", "Vendor listings and custom onboarding"], featured: false }
];

const monetization = [
  ["Freemium directory", "Keep basic search free; charge for advanced filters, saved workspaces, and premium reports."],
  ["API metadata access", "Offer a stable API for model metadata, with usage quotas, keys, and analytics."],
  ["Sponsored listings", "Label sponsorship clearly and keep ranking methodology transparent."],
  ["Enterprise evaluation", "Sell team collaboration, internal model scorecards, procurement reports, and onboarding."],
  ["Partner listings", "Let AI vendors maintain verified profiles and link to official model documentation."]
];

export const metadata = { title: "Pricing & monetization" };

export default function PricingPage() {
  return <main className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-14 lg:px-8">
    <div className="mx-auto max-w-3xl text-center"><p className="text-xs font-semibold uppercase tracking-[.2em] text-blue-300">Pricing & business model</p><h1 className="mt-3 text-4xl font-semibold tracking-tight text-white sm:text-5xl">Useful for free.<br /><span className="text-slate-500">Powerful as you grow.</span></h1><p className="mt-5 leading-7 text-slate-400">AI Model Hub starts as a free model directory. Paid tiers can unlock deeper evaluation, collaboration, and data access as the product matures.</p></div>
    <div className="mt-10 grid gap-4 lg:grid-cols-3">{modelAccess.map((plan) => <article key={plan.title} className={`rounded-2xl border p-6 ${plan.featured ? "border-blue-400/50 bg-blue-500/[.08] shadow-glow" : "border-line bg-panel"}`}><p className="text-xs font-semibold uppercase tracking-widest text-blue-300">{plan.eyebrow}</p><div className="mt-4 flex items-baseline justify-between"><h2 className="text-2xl font-semibold text-white">{plan.title}</h2><p className="text-lg font-semibold text-white">{plan.price}</p></div><p className="mt-3 min-h-[3rem] text-sm leading-6 text-slate-400">{plan.description}</p><ul className="mt-6 space-y-3">{plan.features.map((feature) => <li key={feature} className="flex gap-2 text-sm text-slate-300"><span className="text-blue-300">✓</span>{feature}</li>)}</ul><p className="mt-7 rounded-xl border border-line px-3 py-2 text-center text-xs text-slate-500">{plan.title === "Free" ? "Available in this starter" : "Future roadmap — not currently for sale"}</p></article>)}</div>
    <section className="mt-14"><div className="max-w-2xl"><p className="text-xs font-semibold uppercase tracking-[.2em] text-blue-300">Model access basics</p><h2 className="mt-2 text-2xl font-semibold text-white">Not all “free” models are the same.</h2><p className="mt-3 text-sm leading-6 text-slate-400">A model may have downloadable weights but still require suitable hardware, carry license restrictions, or cost money to host. Commercial APIs may charge per token, image, audio minute, request, or subscription.</p></div><div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{[["Free", "Free-to-use access may have limits, queues, or feature restrictions."],["Open source / weights", "Weights or code may be available; verify the exact license and usage rights."],["Commercial", "Access is governed by a vendor's terms, subscription, or API price."],["Enterprise", "Custom agreements can include security, support, volume, and service terms."]].map(([title, description]) => <div key={title} className="rounded-2xl border border-line bg-panel p-5"><h3 className="font-semibold text-white">{title}</h3><p className="mt-2 text-sm leading-6 text-slate-400">{description}</p></div>)}</div></section>
    <section className="mt-14 rounded-2xl border border-line bg-panel p-6 sm:p-8"><h2 className="text-2xl font-semibold text-white">Monetization roadmap</h2><div className="mt-6 grid gap-5 md:grid-cols-2">{monetization.map(([title, description], index) => <div key={title} className="flex gap-4"><span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-blue-400/20 bg-blue-400/10 text-xs font-bold text-blue-300">0{index + 1}</span><div><h3 className="font-semibold text-white">{title}</h3><p className="mt-1 text-sm leading-6 text-slate-400">{description}</p></div></div>)}</div></section>
    <div className="mt-8 text-center"><Link href="/" className="inline-flex rounded-xl bg-blue-500 px-5 py-3 text-sm font-semibold text-white hover:bg-blue-400">Explore models ↗</Link></div>
  </main>;
}
