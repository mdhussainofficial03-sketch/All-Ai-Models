# AI Model Hub

A responsive, dark-themed AI model directory built with Next.js App Router, TypeScript, and Tailwind CSS. The app uses static sample data and requires no API keys or paid services.

## Requirements
- Node.js 18.17+ (Node 20 LTS recommended)
- npm
- VS Code (optional)

## Setup

If you are creating a fresh folder from scratch, run:

```bash
npx create-next-app@latest . --ts --tailwind --eslint --app --use-npm --src-dir=false --import-alias "@/*"
```

This starter already includes its configuration files, so in this project folder you can simply run:

```bash
npm install
npm run dev
```

Open http://localhost:3000.

To verify a production build:

```bash
npm run build
npm start
```

## Pages
- `/` — searchable, filterable model directory
- `/models/[slug]` — model detail page generated from static data
- `/compare` — sample comparison of Llama 3.1 70B and GPT-4o
- `/pricing` — access categories and future monetization plan
- `not-found.tsx` — 404 page

## Notes about sample data
Model metadata, licenses, release dates, pricing labels, and the score values are illustrative starter data, not live verified benchmarks. Confirm details on official provider pages before using this directory for commercial decisions.

## Future upgrades
- **Prisma + SQLite:** add a schema for models, providers, plans, saved comparisons, and user workspaces. SQLite is suitable for local development; choose a production database based on deployment needs.
- **Hugging Face:** import model cards, tasks, tags, and download statistics from the Hugging Face API.
- **OpenRouter:** pull supported models and API pricing metadata from its models endpoint.
- **Replicate:** add model catalog and prediction API metadata where available.
- **Authentication and billing:** add an auth provider and payment system only after defining account, plan, and billing requirements. Keep API keys on the server and never expose private keys in client-side code.
- **Quality:** add automated tests, data refresh timestamps, admin verification, rate limits, and a clear sponsorship label before launching monetized features.
