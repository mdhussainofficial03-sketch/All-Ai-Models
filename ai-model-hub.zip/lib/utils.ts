export function cn(...classes: Array<string | false | null | undefined>): string {
  return classes.filter(Boolean).join(" ");
}

export function formatContext(context: number): string {
  if (context >= 1_000_000) return `${(context / 1_000_000).toFixed(context % 1_000_000 === 0 ? 0 : 1)}M`;
  if (context >= 1_000) return `${Math.round(context / 1_000)}K`;
  return String(context);
}
