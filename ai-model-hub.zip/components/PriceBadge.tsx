import { cn } from "@/lib/utils";

export default function PriceBadge({ label, compact = false }: { label: string; compact?: boolean }) {
  const isFree = /free|open source/i.test(label);
  return (
    <span className={cn(
      "inline-flex items-center rounded-full border font-medium",
      compact ? "px-2 py-0.5 text-[11px]" : "px-2.5 py-1 text-xs",
      isFree ? "border-emerald-400/20 bg-emerald-400/10 text-emerald-300" : "border-amber-300/20 bg-amber-300/10 text-amber-200"
    )}>
      {label}
    </span>
  );
}
