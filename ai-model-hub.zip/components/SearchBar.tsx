"use client";

export default function SearchBar({ value, onChange }: { value: string; onChange: (value: string) => void }) {
  return (
    <label className="flex w-full items-center gap-3 rounded-2xl border border-line bg-panel px-4 py-3.5 shadow-glow focus-within:border-electric/60">
      <svg aria-hidden="true" className="h-5 w-5 shrink-0 text-slate-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg>
      <input value={value} onChange={(event) => onChange(event.target.value)} placeholder="Search models, providers, or tags..." className="w-full bg-transparent text-sm text-white outline-none placeholder:text-slate-500" />
      <kbd className="hidden rounded-md border border-line px-2 py-1 text-[10px] text-slate-500 sm:inline">SEARCH</kbd>
    </label>
  );
}
