import Link from "next/link";
import type { AIModel } from "@/data/models";
import { formatContext } from "@/lib/utils";
import PriceBadge from "@/components/PriceBadge";

const icons: Record<string, string> = { LLM: "✳", Image: "▧", Audio: "♫", Multimodal: "◈" };

export default function ModelCard({ model }: { model: AIModel }) {
  return (
    <article className="group flex h-full flex-col rounded-2xl border border-line bg-panel/80 p-5 transition duration-200 hover:-translate-y-1 hover:border-slate-600 hover:shadow-glow">
      <div className="mb-5 flex items-start justify-between gap-3">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl border border-white/10 bg-slate-800 text-xl text-blue-300">{icons[model.type]}</div>
        <div className="flex flex-wrap justify-end gap-1.5">
          {model.trending && <span className="rounded-full bg-fuchsia-400/10 px-2 py-1 text-[10px] font-semibold text-fuchsia-300">Trending</span>}
          {model.multimodal && <span className="rounded-full bg-blue-400/10 px-2 py-1 text-[10px] font-semibold text-blue-300">Multimodal</span>}
          {model.localSupport && <span className="rounded-full bg-slate-700/70 px-2 py-1 text-[10px] text-slate-300">Local run</span>}
        </div>
      </div>
      <p className="text-xs font-medium uppercase tracking-[.16em] text-slate-500">{model.provider} <span className="px-1 text-slate-700">/</span> {model.type}</p>
      <h2 className="mt-2 text-lg font-semibold tracking-tight text-white">{model.name}</h2>
      <p className="mt-2 min-h-[4.5rem] text-sm leading-6 text-slate-400">{model.description}</p>
      <div className="mt-4 flex flex-wrap gap-1.5">{model.tags.slice(0, 3).map((tag) => <span key={tag} className="rounded-md border border-line px-2 py-1 text-[11px] text-slate-400">#{tag}</span>)}</div>
      <div className="mt-5 flex items-center justify-between border-t border-line pt-4">
        <div><p className="text-[10px] uppercase tracking-wider text-slate-500">Context</p><p className="mt-1 text-sm font-medium text-slate-200">{model.contextLength ? formatContext(model.contextLength) : "N/A"}</p></div>
        <div className="text-right"><p className="text-[10px] uppercase tracking-wider text-slate-500">Hub score</p><p className="mt-1 text-sm font-semibold text-white">{model.benchmarkScore}<span className="text-slate-500">/100</span></p></div>
      </div>
      <div className="mt-4 flex items-center justify-between gap-2"><PriceBadge label={model.pricingLabel} compact /><span className="text-[11px] text-slate-500">{model.isOpenSource ? "Open weights" : "Commercial"}</span></div>
      <Link href={`/models/${model.slug}`} className="mt-5 inline-flex items-center justify-center gap-2 rounded-xl bg-blue-500 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-blue-400">View details <span aria-hidden="true">↗</span></Link>
    </article>
  );
}
