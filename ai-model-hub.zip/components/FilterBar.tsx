"use client";

import type { ModelType } from "@/data/models";

type Props = {
  type: string;
  setType: (value: string) => void;
  source: string;
  setSource: (value: string) => void;
  price: string;
  setPrice: (value: string) => void;
};

const selectClass = "rounded-xl border border-line bg-panel px-3 py-2.5 text-sm text-slate-200 outline-none focus:border-electric/60";

export default function FilterBar({ type, setType, source, setSource, price, setPrice }: Props) {
  const types: Array<ModelType | "All types"> = ["All types", "LLM", "Image", "Audio", "Multimodal"];
  return (
    <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap">
      <select aria-label="Filter by model type" className={selectClass} value={type} onChange={(e) => setType(e.target.value)}>
        {types.map((item) => <option key={item} value={item}>{item}</option>)}
      </select>
      <select aria-label="Filter by source" className={selectClass} value={source} onChange={(e) => setSource(e.target.value)}>
        <option value="all">All licenses</option><option value="open">Open source / weights</option><option value="commercial">Commercial</option>
      </select>
      <select aria-label="Filter by price" className={selectClass} value={price} onChange={(e) => setPrice(e.target.value)}>
        <option value="all">Free & paid</option><option value="free">Free access / open source</option><option value="paid">Paid / freemium</option>
      </select>
    </div>
  );
}
