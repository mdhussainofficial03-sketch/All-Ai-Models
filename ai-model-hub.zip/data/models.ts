export type ModelType = "LLM" | "Image" | "Audio" | "Multimodal";

export type AIModel = {
  slug: string;
  name: string;
  provider: string;
  type: ModelType;
  category: string;
  description: string;
  isOpenSource: boolean;
  isFree: boolean;
  pricingLabel: string;
  license: string;
  contextLength: number;
  localSupport: boolean;
  releaseDate: string;
  homepageUrl: string;
  docsUrl: string;
  githubUrl: string;
  hfUrl: string;
  tags: string[];
  benchmarkScore: number;
  bestFor: string;
  trending?: boolean;
  multimodal?: boolean;
};

export const models: AIModel[] = [
  {
    slug: "llama-3-1-70b", name: "Llama 3.1 70B", provider: "Meta", type: "LLM", category: "Chat & reasoning",
    description: "A powerful open-weight language model for assistants, coding, reasoning, and multilingual workflows.",
    isOpenSource: true, isFree: true, pricingLabel: "Open source", license: "Llama 3.1 Community License", contextLength: 128000, localSupport: true,
    releaseDate: "2024-07-23", homepageUrl: "https://ai.meta.com/llama/", docsUrl: "https://www.llama.com/", githubUrl: "https://github.com/meta-llama", hfUrl: "https://huggingface.co/meta-llama",
    tags: ["reasoning", "chat", "open weights", "coding"], benchmarkScore: 86, bestFor: "Self-hosted assistants and flexible product integrations", trending: true
  },
  {
    slug: "gpt-4o", name: "GPT-4o", provider: "OpenAI", type: "Multimodal", category: "General assistant",
    description: "A general-purpose model designed for fast text, vision, and audio interactions across many tasks.",
    isOpenSource: false, isFree: false, pricingLabel: "Commercial API", license: "Proprietary", contextLength: 128000, localSupport: false,
    releaseDate: "2024-05-13", homepageUrl: "https://openai.com/", docsUrl: "https://platform.openai.com/docs", githubUrl: "https://github.com/openai", hfUrl: "https://huggingface.co/models",
    tags: ["vision", "audio", "chat", "tools"], benchmarkScore: 91, bestFor: "Production assistants and multimodal applications", multimodal: true, trending: true
  },
  {
    slug: "claude-3-5-sonnet", name: "Claude 3.5 Sonnet", provider: "Anthropic", type: "LLM", category: "Writing & coding",
    description: "A capable model known for coding assistance, careful writing, and nuanced analysis.",
    isOpenSource: false, isFree: false, pricingLabel: "Paid", license: "Proprietary", contextLength: 200000, localSupport: false,
    releaseDate: "2024-06-20", homepageUrl: "https://www.anthropic.com/", docsUrl: "https://docs.anthropic.com/", githubUrl: "https://github.com/anthropics", hfUrl: "https://huggingface.co/models",
    tags: ["coding", "writing", "analysis"], benchmarkScore: 90, bestFor: "Code generation, editing, and complex document work"
  },
  {
    slug: "gemini-1-5-pro", name: "Gemini 1.5 Pro", provider: "Google", type: "Multimodal", category: "Long context",
    description: "A multimodal model family built for long-context understanding and large-document workflows.",
    isOpenSource: false, isFree: false, pricingLabel: "Freemium", license: "Proprietary", contextLength: 2000000, localSupport: false,
    releaseDate: "2024-02-15", homepageUrl: "https://deepmind.google/technologies/gemini/", docsUrl: "https://ai.google.dev/gemini-api/docs", githubUrl: "https://github.com/google-gemini", hfUrl: "https://huggingface.co/models",
    tags: ["long context", "video", "documents", "vision"], benchmarkScore: 88, bestFor: "Large documents, video, and multimodal research", multimodal: true
  },
  {
    slug: "deepseek-v3", name: "DeepSeek V3", provider: "DeepSeek", type: "LLM", category: "Reasoning & coding",
    description: "An efficient open-weight model aimed at strong coding, mathematics, and general-purpose language tasks.",
    isOpenSource: true, isFree: true, pricingLabel: "Open source", license: "Model-specific license", contextLength: 64000, localSupport: true,
    releaseDate: "2024-12-26", homepageUrl: "https://www.deepseek.com/", docsUrl: "https://api-docs.deepseek.com/", githubUrl: "https://github.com/deepseek-ai", hfUrl: "https://huggingface.co/deepseek-ai",
    tags: ["coding", "math", "reasoning", "open weights"], benchmarkScore: 89, bestFor: "Coding prototypes and cost-conscious deployments", trending: true
  },
  {
    slug: "mistral-large", name: "Mistral Large", provider: "Mistral AI", type: "LLM", category: "Enterprise chat",
    description: "A commercial language model for multilingual assistants, complex instruction following, and business workflows.",
    isOpenSource: false, isFree: false, pricingLabel: "Paid", license: "Proprietary", contextLength: 128000, localSupport: false,
    releaseDate: "2024-02-26", homepageUrl: "https://mistral.ai/", docsUrl: "https://docs.mistral.ai/", githubUrl: "https://github.com/mistralai", hfUrl: "https://huggingface.co/mistralai",
    tags: ["multilingual", "enterprise", "chat"], benchmarkScore: 85, bestFor: "Business assistants and multilingual applications"
  },
  {
    slug: "qwen2-72b", name: "Qwen2 72B", provider: "Alibaba Cloud", type: "LLM", category: "Open-weight LLM",
    description: "A multilingual open-weight model with broad language coverage and strong general-purpose capabilities.",
    isOpenSource: true, isFree: true, pricingLabel: "Open source", license: "Qwen License", contextLength: 32768, localSupport: true,
    releaseDate: "2024-06-07", homepageUrl: "https://qwenlm.github.io/", docsUrl: "https://qwen.readthedocs.io/", githubUrl: "https://github.com/QwenLM", hfUrl: "https://huggingface.co/Qwen",
    tags: ["multilingual", "open weights", "chat"], benchmarkScore: 84, bestFor: "Multilingual applications and local experimentation"
  },
  {
    slug: "stable-diffusion-3", name: "Stable Diffusion 3", provider: "Stability AI", type: "Image", category: "Image generation",
    description: "A text-to-image model family for creating visuals from detailed natural-language prompts.",
    isOpenSource: false, isFree: false, pricingLabel: "Freemium", license: "Model-specific community license", contextLength: 0, localSupport: true,
    releaseDate: "2024-06-12", homepageUrl: "https://stability.ai/", docsUrl: "https://platform.stability.ai/docs", githubUrl: "https://github.com/Stability-AI", hfUrl: "https://huggingface.co/stabilityai",
    tags: ["image", "text-to-image", "creative"], benchmarkScore: 82, bestFor: "Creative assets, concept art, and visual prototypes"
  },
  {
    slug: "whisper-large-v3", name: "Whisper Large V3", provider: "OpenAI", type: "Audio", category: "Speech recognition",
    description: "An automatic speech recognition model for transcribing multilingual audio and speech.",
    isOpenSource: true, isFree: true, pricingLabel: "Open source", license: "MIT", contextLength: 0, localSupport: true,
    releaseDate: "2023-11-06", homepageUrl: "https://openai.com/research/whisper", docsUrl: "https://github.com/openai/whisper", githubUrl: "https://github.com/openai/whisper", hfUrl: "https://huggingface.co/openai/whisper-large-v3",
    tags: ["audio", "transcription", "speech", "multilingual"], benchmarkScore: 87, bestFor: "Transcription, subtitles, and speech-to-text pipelines"
  },
  {
    slug: "gemma-2-27b", name: "Gemma 2 27B", provider: "Google", type: "LLM", category: "Open-weight assistant",
    description: "An open model designed for accessible experimentation, research, and efficient assistant applications.",
    isOpenSource: true, isFree: true, pricingLabel: "Open source", license: "Gemma Terms of Use", contextLength: 8192, localSupport: true,
    releaseDate: "2024-06-27", homepageUrl: "https://ai.google.dev/gemma", docsUrl: "https://ai.google.dev/gemma/docs", githubUrl: "https://github.com/google-deepmind", hfUrl: "https://huggingface.co/google/gemma-2-27b",
    tags: ["open weights", "research", "chat"], benchmarkScore: 83, bestFor: "Local experiments and research prototypes"
  }
];

export function getModel(slug: string): AIModel | undefined {
  return models.find((model) => model.slug === slug);
}
