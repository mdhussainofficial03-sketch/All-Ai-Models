import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{js,ts,jsx,tsx,mdx}", "./components/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        ink: "#070b14",
        panel: "#0d1422",
        line: "#202c40",
        electric: "#5b8cff"
      },
      boxShadow: { glow: "0 0 40px rgba(91,140,255,.12)" }
    }
  },
  plugins: []
};
export default config;
